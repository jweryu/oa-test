package com.webtest.demo;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
import com.webtest.core.SeleniumScreenShot;
import com.webtest.core.WebTestListener;
import com.webtest.dataprovider.NSDataProvider;

@Listeners(WebTestListener.class)
public class Front_Login_Test extends BaseTest {

//	Login_Action action;
//	@BeforeMethod
//	public void setup() {
//		action=new Login_Action(webtest);
//		
//	}
	
	@Test
	public void loginSucess() {
		webtest.open("http://localhost:8033/tscoa/login.php");
//		action.login("admin", "admin123");
	}
	
	
//	@Test
//	public void loginFail() {
//		webtest.open("http://localhost:8032/tscoa/login.php");
//		action.login("admin","yujunwei");
//		assertTrue(webtest.ifContains("�˳�"));
//		
//		
//	}
	


}
