import unittest
from api2018.Sendhttp import SendHttp
from api2018 import Common
class transportfree(unittest.TestCase):
    def setUp(self):
        self.loginurl="/common/fgadmin/login"
        self.getfreeurl="/common/getTransportFee"
    def test_getFreeSuccess(self):
        data={"id":"1",
              "addressDetail":"浙江省_杭州市_滨江区"
              }
        fee_result1=SendHttp().sent_get(self.getfreeurl,data)
        print(fee_result1)
        self.assertEqual(fee_result1['code'],200)
    def test_getFreeFail(self):
        data={"id":"",
              "addressDetail":"河北省_石家庄市_裕华区市"
              }
        fee_result1=SendHttp().sent_get(self.getfreeurl,data)
        print(fee_result1)
        self.assertEqual(fee_result1['code'],200)
    def test_getSuccess2(self):
        data={"id":1,
              "addressDetail":"河北省_石家庄市_裕华区市"
              }
        fee_result1=SendHttp().sent_get(self.getfreeurl,data)
        print(fee_result1)
        self.assertEqual(fee_result1['code'],200)

    def test_getFreeFail2(self):
        data={"id":"3",
              "addressDetail":"浙江省_石家庄市_裕华区市"
              }
        fee_result1=SendHttp().sent_get(self.getfreeurl,data)
        print(fee_result1)
        self.assertEqual(fee_result1['code'],200)
    def test_getFreeFail3(self):
        data={"id":"4",
              "addressDetail":""
              }
        fee_result1=SendHttp().sent_get(self.getfreeurl,data)
        print(fee_result1)
        self.assertEqual(fee_result1['code'],200)
